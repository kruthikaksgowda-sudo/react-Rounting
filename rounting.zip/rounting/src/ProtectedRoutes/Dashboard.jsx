import React from 'react'

function Dashboard() {
  return (
    <div>this is a DashBoard</div>
  )
}

export default Dashboard