import React from 'react';
import { Link } from 'react-router-dom';

function Home() {
  return (
    <div>
      <h2>This is Home Page</h2>
      <Link to="/login">Go to Login Page</Link>
      <Link to="/users/:kruthika"> kruthika</Link>
    </div>
  );
}

export default Home;