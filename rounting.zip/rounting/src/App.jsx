import React from 'react';
import ProtectedRoutes from './ProtectedRoutes/ProtectedRoutes';
import Login from './ProtectedRoutes/Login';
import Dashboard from './ProtectedRoutes/Dashboard';
import Home from './ProtectedRoutes/Home';
import User from './DynamicRouting';
import { BrowserRouter, Routes, Route } from 'react-router-dom';


function App() {
  return (
    <div>
      <h2>React Protected Routes Example</h2>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/users/:id" element={<User/>}/>
          <Route
            path="/dashboard"
            element={
              <ProtectedRoutes>
                <Dashboard />
              </ProtectedRoutes>
            }
          />
        </Routes>
      </BrowserRouter>
      
    </div>
  );
}

export default App;